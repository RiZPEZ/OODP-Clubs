public class Soccer extends Club{

    public Soccer(String name) {
        super(name);
    }


}
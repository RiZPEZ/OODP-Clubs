public class Swim extends Club{

    public Swim(String name) {
        super(name);
    }


}

public class Basketball extends Club{

    public Basketball(String name) {
        super(name);
    }


}